function calculate(basic) {
    var total = 0;
    for (let i = 0; i < basic; i++) {
        total += i;
        document.getElementById('txtOutput').innerHTML += i + " ";
    }
    document.getElementById('txtTotal').innerHTML += total;
    //let salary = parseInt(basic) + parseInt(allowance);

}