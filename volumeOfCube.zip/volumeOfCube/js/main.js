function volume(length) {
    volume = length * length * length;
    document.getElementById('txtVolumeOutput').innerHTML = volume;
}